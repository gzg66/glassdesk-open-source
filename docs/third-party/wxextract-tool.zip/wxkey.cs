// wxkey.cs — 微信 4.1+ (Windows) 数据库密钥候选提取器
// 只读：OpenProcess(VmRead) + ReadProcessMemory + VirtualQueryEx。不注入、不 hook、不改内存。
// 算法参考 TANGandXUE/wcdb-key-tool (MIT) 的 Windows 4.1 runtime Config.Cipher 扫描路线。
// 用法:
//   wxkey.exe scan [pid]            扫内存，打印候选 key/salt/blob
//   wxkey.exe dump [pid] <outdir>   把进程所有可读私有内存导出成 memdump.bin + regions.tsv
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;

static class Program
{
    const uint PROCESS_QUERY_INFORMATION = 0x0400;
    const uint PROCESS_VM_READ = 0x0010;
    const uint MEM_COMMIT = 0x1000;
    const uint PAGE_NOACCESS = 0x01;
    const uint PAGE_GUARD = 0x100;
    const uint MEM_PRIVATE = 0x20000;

    static readonly byte[] NEEDLE = Encoding.ASCII.GetBytes("com.Tencent.WCDB.Config.Cipher");
    static readonly byte[] XOR_MASK = HexToBytes("d2c7442458020000004889442450488b450048844c2448488944254048584c24");
    static readonly Regex LITERAL_RE = new Regex(@"[xX]'([0-9a-fA-F]{64,192})'", RegexOptions.Compiled);
    const int KEY_SZ = 32;
    const int CHUNK = 4 * 1024 * 1024;
    const int OVERLAP = 0x100;
    const long MAX_USER_ADDR = 0x0000800000000000L;

    [StructLayout(LayoutKind.Sequential)]
    struct MBI
    {
        public IntPtr BaseAddress;
        public IntPtr AllocationBase;
        public uint AllocationProtect;
        public IntPtr RegionSize;
        public uint State;
        public uint Protect;
        public uint Type;
    }

    [DllImport("kernel32.dll", SetLastError = true)]
    static extern IntPtr OpenProcess(uint access, bool inherit, int pid);
    [DllImport("kernel32.dll", SetLastError = true)]
    static extern bool ReadProcessMemory(IntPtr h, IntPtr addr, byte[] buf, IntPtr size, out IntPtr read);
    [DllImport("kernel32.dll", SetLastError = true)]
    static extern IntPtr VirtualQueryEx(IntPtr h, IntPtr addr, out MBI mbi, IntPtr length);
    [DllImport("kernel32.dll", SetLastError = true)]
    static extern bool CloseHandle(IntPtr h);
    [DllImport("kernel32.dll", SetLastError = true)]
    static extern IntPtr GetCurrentProcess();
    [DllImport("advapi32.dll", SetLastError = true)]
    static extern bool OpenProcessToken(IntPtr h, uint access, out IntPtr token);
    [DllImport("advapi32.dll", SetLastError = true)]
    static extern bool LookupPrivilegeValue(string system, string name, out LUID luid);
    [DllImport("advapi32.dll", SetLastError = true)]
    static extern bool AdjustTokenPrivileges(IntPtr token, bool disableAll, ref TOKEN_PRIVILEGES newState, uint len, IntPtr prev, IntPtr retLen);

    // 注意：LUID 是 2 个 DWORD（共 8 字节，4 字节对齐）。若写成 long 字段，
    // CLR 默认 Pack=8 会在 Count 后插 4 字节填充，整体变 24 字节，与 native 的 16 字节不符。
    [StructLayout(LayoutKind.Sequential)]
    struct LUID { public uint LowPart; public int HighPart; }

    [StructLayout(LayoutKind.Sequential)]
    struct TOKEN_PRIVILEGES { public uint Count; public LUID Luid; public uint Attributes; }

    class Region { public long Base; public long Size; public uint Type; }

    static bool TryEnableDebugPrivilege()
    {
        try
        {
            IntPtr tok;
            if (!OpenProcessToken(GetCurrentProcess(), 0x0020 | 0x0008, out tok)) return false;
            LUID luid;
            if (!LookupPrivilegeValue(null, "SeDebugPrivilege", out luid)) return false;
            TOKEN_PRIVILEGES tp = new TOKEN_PRIVILEGES();
            tp.Count = 1; tp.Luid = luid; tp.Attributes = 0x2;
            if (!AdjustTokenPrivileges(tok, false, ref tp, 0, IntPtr.Zero, IntPtr.Zero)) return false;
            // 返回 TRUE 也可能是"部分成功"：真正生效要看 GetLastError 是否为 ERROR_NOT_ALL_ASSIGNED
            return Marshal.GetLastWin32Error() == 0;
        }
        catch { return false; }
    }

    static byte[] HexToBytes(string s)
    {
        byte[] b = new byte[s.Length / 2];
        for (int i = 0; i < b.Length; i++) b[i] = byte.Parse(s.Substring(i * 2, 2), NumberStyles.HexNumber);
        return b;
    }

    static string ToHex(byte[] d, int off, int len)
    {
        StringBuilder sb = new StringBuilder(len * 2);
        for (int i = 0; i < len; i++) sb.Append(d[off + i].ToString("x2"));
        return sb.ToString();
    }

    static bool Readable(uint protect)
    {
        if ((protect & PAGE_GUARD) != 0) return false;
        uint p = protect & 0xFF;
        if (p == PAGE_NOACCESS || p == 0) return false;
        return p == 0x02 || p == 0x04 || p == 0x08 || p == 0x20 || p == 0x40 || p == 0x80;
    }

    static List<Region> EnumRegions(IntPtr h)
    {
        List<Region> list = new List<Region>();
        long addr = 0;
        MBI mbi;
        IntPtr size = (IntPtr)Marshal.SizeOf(typeof(MBI));
        while (addr < MAX_USER_ADDR)
        {
            if (VirtualQueryEx(h, (IntPtr)addr, out mbi, size) == IntPtr.Zero) break;
            long rs = mbi.RegionSize.ToInt64();
            long baseAddr = mbi.BaseAddress.ToInt64();
            if (rs <= 0) break;
            if (mbi.State == MEM_COMMIT && Readable(mbi.Protect))
                list.Add(new Region { Base = baseAddr, Size = rs, Type = mbi.Type });
            long next = baseAddr + rs;
            if (next <= addr) break;
            addr = next;
        }
        return list;
    }

    // 读一段内存；部分读成功则返回已读到的部分，完全失败返回 null
    static byte[] ReadMem(IntPtr h, long baseAddr, long size)
    {
        byte[] buf = new byte[size];
        long off = 0;
        while (off < size)
        {
            int want = (int)Math.Min(4L * 1024 * 1024, size - off);
            byte[] tmp = new byte[want];
            IntPtr got;
            if (!ReadProcessMemory(h, (IntPtr)(baseAddr + off), tmp, (IntPtr)want, out got))
            {
                if (off == 0) return null;
                Array.Resize(ref buf, (int)off);
                return buf;
            }
            int n = got.ToInt32();
            Array.Copy(tmp, 0, buf, off, n);
            off += n;
            if (n < want) break;
        }
        if (off == 0) return null;
        if (off != size) Array.Resize(ref buf, (int)off);
        return buf;
    }

    static void FindAll(byte[] hay, byte[] needle, List<int> hits)
    {
        int n = needle.Length;
        byte f = needle[0];
        int last = hay.Length - n;
        for (int i = 0; i <= last; i++)
        {
            if (hay[i] != f) continue;
            int j = 1;
            while (j < n && hay[i + j] == needle[j]) j++;
            if (j == n) hits.Add(i);
        }
    }

    static long U64(byte[] d, int off)
    {
        if (d == null || off < 0 || off + 8 > d.Length) return 0;
        return BitConverter.ToInt64(d, off);
    }

    static bool ProbableKey(byte[] k)
    {
        if (k.Length != KEY_SZ) return false;
        HashSet<byte> s = new HashSet<byte>();
        for (int i = 0; i < k.Length; i++) s.Add(k[i]);
        return s.Count >= 15;
    }

    static int ScanCandidates(IntPtr h, List<Region> regions, int pid)
    {
        Console.WriteLine("[*] regions={0} total={1:F1}MB", regions.Count, TotalMB(regions));

        // pass 1: needle 地址
        HashSet<long> needleAddrs = new HashSet<long>();
        long t0 = Environment.TickCount;
        foreach (Region r in regions)
        {
            long off = 0;
            byte[] tail = null; long tailBase = 0;
            while (off < r.Size)
            {
                int want = (int)Math.Min((long)CHUNK, r.Size - off);
                byte[] chunk = ReadMem(h, r.Base + off, want);
                byte[] data;
                long dataBase;
                if (tail != null) { data = new byte[tail.Length + (chunk == null ? 0 : chunk.Length)]; Array.Copy(tail, 0, data, 0, tail.Length); if (chunk != null) Array.Copy(chunk, 0, data, tail.Length, chunk.Length); dataBase = tailBase; }
                else { data = chunk; dataBase = r.Base + off; }
                if (data != null && data.Length > 0)
                {
                    List<int> hits = new List<int>();
                    FindAll(data, NEEDLE, hits);
                    foreach (int p in hits) needleAddrs.Add(dataBase + p);
                    int ov = Math.Min(OVERLAP, data.Length);
                    tail = new byte[ov]; Array.Copy(data, data.Length - ov, tail, 0, ov); tailBase = dataBase + data.Length - ov;
                }
                else { tail = null; tailBase = r.Base + off + want; }
                off += want;
            }
        }
        Console.WriteLine("[*] needle occurrences = {0}  ({1}ms)", needleAddrs.Count, Environment.TickCount - t0);
        if (needleAddrs.Count == 0) { Console.WriteLine("[!] needle not found in readable memory"); return 0; }

        long lenVal = NEEDLE.Length;
        HashSet<long> seenConfig = new HashSet<long>();
        HashSet<string> seenCand = new HashSet<string>();
        int nodeHits = 0, blobCount = 0, candCount = 0;
        TextWriter rep = Console.Out;

        // pass 2: 找 (ptr,len) 字符串对象引用
        foreach (Region r in regions)
        {
            long off = 0;
            byte[] tail = null; long tailBase = 0;
            while (off < r.Size)
            {
                int want = (int)Math.Min((long)CHUNK, r.Size - off);
                byte[] chunk = ReadMem(h, r.Base + off, want);
                byte[] data; long dataBase;
                if (tail != null) { data = new byte[tail.Length + (chunk == null ? 0 : chunk.Length)]; Array.Copy(tail, 0, data, 0, tail.Length); if (chunk != null) Array.Copy(chunk, 0, data, tail.Length, chunk.Length); dataBase = tailBase; }
                else { data = chunk; dataBase = r.Base + off; }
                if (data != null)
                {
                    for (int i = 0; i + 16 <= data.Length; i += 8)
                    {
                        long p0 = BitConverter.ToInt64(data, i);
                        if (!needleAddrs.Contains(p0)) continue;
                        long p1 = BitConverter.ToInt64(data, i + 8);
                        if (p1 != lenVal) continue;
                        long qaddr = dataBase + i;
                        nodeHits++;
                        byte[] node = ReadMem(h, qaddr - 0x10, 0x50);
                        if (node == null || node.Length < 0x40) continue;
                        if (!needleAddrs.Contains(U64(node, 0x10)) || U64(node, 0x18) != lenVal) continue;
                        long configPtr = U64(node, 0x28);
                        if (configPtr < 0x10000 || configPtr >= MAX_USER_ADDR) continue;
                        seenConfig.Add(configPtr);
                        byte[] obj = ReadMem(h, configPtr + 0x88, 0x28);
                        if (obj == null || obj.Length < 0x18) continue;
                        long dataPtr = U64(obj, 0x8);
                        long dataLen = U64(obj, 0x10);
                        if (dataLen <= 0 || dataLen > 1024 || dataPtr < 0x10000 || dataPtr >= MAX_USER_ADDR) continue;
                        byte[] blob = ReadMem(h, dataPtr, dataLen);
                        if (blob == null || blob.Length != (int)dataLen) continue;
                        blobCount++;
                        byte[] dec = new byte[blob.Length];
                        for (int k = 0; k < blob.Length; k++) dec[k] = (byte)(blob[k] ^ XOR_MASK[k % XOR_MASK.Length]);
                        string text = Encoding.GetEncoding(28591).GetString(dec);
                        rep.WriteLine("[BLOCK] len={0} blob={1}", blob.Length, ToHex(blob, 0, blob.Length));
                        rep.WriteLine("[BLOCK] decoded={0}", text.Replace("\0", "."));
                        foreach (Match m in LITERAL_RE.Matches(text))
                        {
                            string run = m.Groups[1].Value.ToLowerInvariant();
                            List<int> starts = new List<int>();
                            starts.Add(0);
                            if (run.Length > 96)
                            {
                                for (int s = 0; s <= run.Length - 64; s += 32) starts.Add(s);
                                starts.Add(run.Length - 64);
                            }
                            HashSet<int> uniq = new HashSet<int>(starts);
                            foreach (int start in uniq)
                            {
                                if (start < 0 || start + 64 > run.Length) continue;
                                byte[] key = HexToBytes(run.Substring(start, 64));
                                if (!ProbableKey(key)) continue;
                                string salt = (start + 96 <= run.Length) ? run.Substring(start + 64, 32) : null;
                                string item = run.Substring(start, 64) + "|" + (salt ?? "-");
                                if (!seenCand.Add(item)) continue;
                                candCount++;
                                rep.WriteLine("[CAND] PID={0} KEY={1} SALT={2} off={3}", pid, run.Substring(start, 64), salt ?? "-", start);
                                rep.Flush();
                            }
                        }
                    }
                    int ov = Math.Min(OVERLAP, data.Length);
                    tail = new byte[ov]; Array.Copy(data, data.Length - ov, tail, 0, ov); tailBase = dataBase + data.Length - ov;
                }
                else { tail = null; }
                off += want;
            }
        }
        rep.Flush();
        Console.WriteLine("[*] pair refs={0} configs={1} blobs={2} candidates={3}", nodeHits, seenConfig.Count, blobCount, candCount);
        return candCount;
    }

    static double TotalMB(List<Region> regions)
    {
        double t = 0; foreach (Region r in regions) t += r.Size;
        return t / 1048576.0;
    }

    static int Dump(IntPtr h, List<Region> regions, string outDir)
    {
        Directory.CreateDirectory(outDir);
        string binPath = Path.Combine(outDir, "memdump.bin");
        string idxPath = Path.Combine(outDir, "regions.tsv");
        using (FileStream fs = new FileStream(binPath, FileMode.Create, FileAccess.Write))
        using (StreamWriter idx = new StreamWriter(idxPath))
        {
            idx.WriteLine("offset\tbase\tsize\ttype");
            foreach (Region r in regions)
            {
                if (r.Type != MEM_PRIVATE) continue;
                byte[] d = ReadMem(h, r.Base, r.Size);
                if (d == null || d.Length == 0) continue;
                long off = fs.Position;
                fs.Write(d, 0, d.Length);
                idx.WriteLine("{0}\t{1:x}\t{2}\tprivate", off, r.Base, d.Length);
            }
        }
        Console.WriteLine("[+] dump done: {0}", binPath);
        return 0;
    }

    static List<int> FindPids()
    {
        List<KeyValuePair<long, int>> found = new List<KeyValuePair<long, int>>();
        foreach (Process p in Process.GetProcessesByName("Weixin"))
        {
            try
            {
                long ws = p.WorkingSet64;
                Console.WriteLine("[*] Weixin.exe pid={0} {1}MB", p.Id, ws / 1048576);
                found.Add(new KeyValuePair<long, int>(ws, p.Id));
            }
            catch { }
        }
        // 内存占用大的排前面（主进程通常最大），但**全部都扫**：
        // 同一台机器上可能同时登着/残留着多个账号，各账号密钥不同，靠后面的 HMAC 校验来筛。
        found.Sort((a, b) => b.Key.CompareTo(a.Key));
        List<int> pids = new List<int>();
        foreach (KeyValuePair<long, int> kv in found) pids.Add(kv.Value);
        return pids;
    }

    static int Main(string[] args)
    {
        string mode = args.Length > 0 ? args[0].ToLowerInvariant() : "scan";
        int pid = -1;
        string outDir = ".";
        int firstFree = 1;
        int parsedPid;
        if (args.Length > 1 && int.TryParse(args[1], out parsedPid)) { pid = parsedPid; firstFree = 2; }
        if (mode == "dump" && args.Length > firstFree) outDir = args[firstFree];

        List<int> pids = new List<int>();
        if (pid > 0) pids.Add(pid); else pids = FindPids();
        if (pids.Count == 0) { Console.WriteLine("[!] Weixin.exe not found"); return 2; }
        Console.WriteLine("[*] 共 {0} 个 Weixin.exe 进程待扫, debugPriv={1}, x64={2}", pids.Count, TryEnableDebugPrivilege(), Environment.Is64BitProcess);

        int totalCands = 0;
        int opened = 0;
        foreach (int p in pids)
        {
            IntPtr h = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, false, p);
            if (h == IntPtr.Zero)
            {
                Console.WriteLine("[!] pid={0} OpenProcess failed err={1}（跳过；需要管理员权限）", p, Marshal.GetLastWin32Error());
                continue;
            }
            opened++;
            try
            {
                List<Region> regions = EnumRegions(h);
                if (mode == "dump")
                {
                    return Dump(h, regions, outDir);
                }
                Console.WriteLine("[*] --- 扫描 pid={0} ---", p);
                totalCands += ScanCandidates(h, regions, p);
            }
            finally { CloseHandle(h); }
        }
        if (opened == 0) { Console.WriteLine("[!] 一个微信进程都打不开（试管理员运行）"); return 3; }
        return totalCands > 0 ? 0 : 1;
    }
}
