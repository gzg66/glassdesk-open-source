#!/usr/bin/env python3
"""微信 4.x 已解密库 → 聊天记录导出（JSONL + 可读 TXT + index.json）。

用法:
    python3 wxexport.py --decrypted decrypted --out export --self-id wxid_xxx
（--self-id 缺省时依次尝试环境变量 WX_SELF_ID、从目录名推断）
"""
import argparse
import ctypes
import hashlib
import html
import json
import os
import re
import sqlite3
import sys
import time
import datetime

try:  # 输出被重定向到文件时，Windows 默认用 ANSI 代码页，中文会炸
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

# ---------- zstd ----------
# 优先用 zstandard 模块；否则找同目录的 libzstd 动态库
# （Windows 随包发官方 facebook/zstd 的 libzstd.dll；Linux 用系统 libzstd.so.1）
_zstd = None
_ZSTD_DLLS = ("libzstd.dll", "zstd.dll", "libzstd.so.1", "libzstd.so", "libzstd.dylib")


def _load_zstd():
    global _zstd
    if _zstd is not None:
        return _zstd
    try:
        import zstandard as _mod
        _zstd = ("module", _mod)
        return _zstd
    except ImportError:
        pass
    here = os.path.dirname(os.path.abspath(__file__))
    for name in _ZSTD_DLLS:
        for cand in (os.path.join(here, name), name):
            try:
                lib = ctypes.WinDLL(cand) if os.name == "nt" else ctypes.CDLL(cand)
            except OSError:
                continue
            lib.ZSTD_getFrameContentSize.restype = ctypes.c_ulonglong
            lib.ZSTD_getFrameContentSize.argtypes = [ctypes.c_void_p, ctypes.c_size_t]
            lib.ZSTD_decompress.restype = ctypes.c_size_t
            lib.ZSTD_decompress.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p, ctypes.c_size_t]
            lib.ZSTD_isError.restype = ctypes.c_uint
            lib.ZSTD_isError.argtypes = [ctypes.c_size_t]
            _zstd = ("ctypes", lib)
            return _zstd
    raise RuntimeError(
        "没找到 zstd 解压能力。二选一：\n"
        "  a) 把官方 libzstd.dll 放到脚本同目录（本项目已带）\n"
        "  b) pip install zstandard")


def zstd_decompress(data: bytes):
    kind, impl = _load_zstd()
    if kind == "module":
        try:
            return impl.ZstdDecompressor().decompressobj().decompress(data)
        except Exception:
            return None
    src = ctypes.create_string_buffer(data, len(data))
    size = impl.ZSTD_getFrameContentSize(src, len(data))
    if size == 0xFFFFFFFFFFFFFFFF or size > (1 << 30):  # 未知/过大：逐步扩容量
        cap = max(len(data) * 40, 1 << 20)
        for _ in range(4):
            dst = ctypes.create_string_buffer(cap)
            n = impl.ZSTD_decompress(dst, cap, src, len(data))
            if not impl.ZSTD_isError(n):
                return dst.raw[:n]
            cap *= 4
        return None
    dst = ctypes.create_string_buffer(int(size))
    n = impl.ZSTD_decompress(dst, int(size), src, len(data))
    if impl.ZSTD_isError(n):
        return None
    return dst.raw[:n]


def decode_content(raw):
    """message_content → 文本（必要时 zstd 解压）。返回 (text, was_zstd)。"""
    if raw is None:
        return "", False
    if isinstance(raw, str):
        return raw, False
    if raw[:4] == b"\x28\xb5\x2f\xfd":
        out = zstd_decompress(raw)
        if out is None:
            return "<zstd解压失败>", True
        return out.decode("utf-8", "replace"), True
    return raw.decode("utf-8", "replace"), False


def xml_field(text, key):
    m = re.search(rf"<{key}>(.{0,400}?)</{key}>", text, re.S)
    return html.unescape(m.group(1).strip()) if m else ""


TYPE_NAME = {
    1: "文本", 3: "图片", 34: "语音", 37: "好友请求", 42: "名片", 43: "视频",
    47: "表情", 48: "位置", 49: "链接/文件/引用", 50: "音视频通话", 51: "状态",
    53: "语音通话", 62: "短视频", 66: "微信运动", 10000: "系统", 10002: "撤回",
}


def render(mtype, content):
    """把消息内容渲染成人可读的一行。mtype 为 local_type & 0xFFFFFFFF。"""
    if mtype == 1:
        return content.strip()
    if mtype == 3:
        return "[图片]"
    if mtype == 34:
        return "[语音]"
    if mtype == 43:
        return "[视频]"
    if mtype == 47:
        a = xml_field(content, "alias")
        return f"[表情 {a}]" if a else "[表情]"
    if mtype == 48:
        return f"[位置] {xml_field(content, 'label') or xml_field(content, 'poiname')}"
    if mtype == 42:
        return f"[名片] {xml_field(content, 'nickname')}"
    if mtype == 49:
        return render_appmsg(content)
    if mtype == 50:
        return "[音视频通话]"
    if mtype == 10000:
        t = re.sub(r"<[^>]+>", "", content)
        return f"[系统] {html.unescape(t).strip()}"
    if mtype == 10002:
        return "[撤回]"
    return f"[{TYPE_NAME.get(mtype, mtype)}]"


APPMSG_TYPE = {
    0: "文本/通知", 1: "文本", 3: "音乐", 4: "视频", 5: "链接", 6: "文件", 7: "群邀请",
    8: "表情", 9: "小程序", 10: "引用回复", 13: "名片", 14: "视频通话", 15: "游戏",
    16: "位置", 17: "卡片链接", 19: "聊天记录", 24: "笔记", 33: "小程序", 36: "小程序",
    43: "视频号", 44: "视频号直播", 46: "音乐", 49: "聊天记录", 51: "视频号",
    53: "接龙", 57: "引用回复", 62: "直播", 63: "直播", 87: "群公告",
    2000: "转账", 2001: "红包", 2002: "红包封面", 2003: "接龙",
}


def render_appmsg(content):
    """base type 49 的应用消息：拿 <type> 和 <title> 拼一句人话。"""
    sub = 0
    m = re.search(r"<type>(\d{1,6})</type>", content)
    if m:
        sub = int(m.group(1))
    label = APPMSG_TYPE.get(sub, f"应用{sub}" if sub else "应用消息")
    title = xml_field(content, "title") or xml_field(content, "des") or xml_field(content, "filename")
    fname = xml_field(content, "filename")
    if sub == 6 and fname:
        title = fname
    if sub in (57, 10):
        ref = xml_field(content, "content")
        if ref:
            return f"[引用] {title} ⟵ {ref[:60]}"
    return f"[{label}] {title}".strip()


# ---------- 联系人 ----------
def _columns(con, table):
    try:
        return {c[1] for c in con.execute(f"pragma table_info({table})")}
    except sqlite3.Error:
        return set()


def load_contacts(contact_db):
    out = {}
    if not os.path.exists(contact_db):
        return out
    con = sqlite3.connect(f"file:{contact_db}?mode=ro", uri=True)
    members = out.setdefault("__member__", {})
    try:  # 一个个查：某张表在当前微信版本里不存在，不应连带跳过后面的查询
        for username, remark, nick, alias in con.execute(
            "select username, remark, nick_name, alias from contact"
        ):
            if not username:
                continue
            name = remark or nick or alias or username
            out[username] = {"name": name, "remark": remark or "", "nick": nick or "", "alias": alias or ""}
    except sqlite3.Error as e:
        print(f"   (contact 表读取失败，跳过: {e})")
    # 群成员昵称：不同微信版本列名不同，4.1.x 的 chatroom_member 只有 (room_id, member_id)，
    # 那就没有昵称可用，回退到联系人名（不要为此报“失败”，那是版本差异不是错误）。
    cols = _columns(con, "chatroom_member")
    name_col = next((c for c in ("display_name", "nick_name", "name") if c in cols), None)
    if name_col:
        try:
            for room_id, member, disp in con.execute(
                f"select room_id, member_id, {name_col} from chatroom_member"
            ):
                if room_id and member and disp:
                    members[f"{room_id}|{member}"] = disp
        except sqlite3.Error as e:
            print(f"   (群昵称读取失败，回退联系人名: {e})")
    else:
        print("   (该版本 contact.db 不存群昵称，群消息发送者用联系人名)")
    con.close()
    return out


def build_hash_map(contact_db, msg_dbs, session_db):
    """md5(标识) → 标识，用于把 Msg_<md5> 反解成会话对象。"""
    ids = set()
    qs = [
        (contact_db, "select username from contact"),
        (contact_db, "select username from name2id"),
        (contact_db, "select username from chat_room"),
        (contact_db, "select room_id from chatroom_member"),
        (contact_db, "select member_id from chatroom_member"),
        (contact_db, "select username from stranger"),
        (session_db, "select username from SessionTable"),
        (session_db, "select user_name from Name2Id"),
    ]
    for db, sql in qs:
        if not db or not os.path.exists(db):
            continue
        try:
            con = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
            for (v,) in con.execute(sql):
                if v:
                    ids.add(v if isinstance(v, str) else str(v))
            con.close()
        except sqlite3.Error as e:
            print(f"   (hash 索引：{sql} 读取失败，跳过: {e})")
    for db in msg_dbs:
        if not os.path.exists(db):
            continue
        try:
            con = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
            for (v,) in con.execute("select user_name from Name2Id"):
                if v:
                    ids.add(v if isinstance(v, str) else str(v))
            con.close()
        except sqlite3.Error as e:
            print(f"   (hash 索引：{os.path.basename(db)}.Name2Id 读取失败，跳过: {e})")
    return {hashlib.md5(i.encode()).hexdigest(): i for i in ids}


GROUP_SUFFIX = "@chatroom"
SERVICE_IDS = {"notifymessage", "floatbottle", "medianote", "qqmail", "tmessage", "qmessage", "newsapp"}


def safe_name(talker: str) -> str:
    """会话 id 会当文件名用，去掉路径分隔符等危险字符。"""
    return re.sub(r"[^0-9A-Za-z_@.\-]", "_", talker)[:120] or "unknown"


def is_service_talker(talker: str, from_biz_db: bool = False) -> bool:
    """公众号 / 服务号 / 系统号（不是真人单聊，也不是群）。"""
    t = talker or ""
    return bool(from_biz_db) or t.startswith("gh_") or t.endswith("@openim") or t in SERVICE_IDS


def _fmt_time(ts, fmt="%Y-%m-%d %H:%M:%S"):
    """时间戳可能越界/NULL（坏行），不能让它掀掉整个导出。"""
    try:
        return datetime.datetime.fromtimestamp(int(ts)).strftime(fmt)
    except (ValueError, OSError, OverflowError, TypeError):
        return f"<ts:{ts}>"


GROUP_PREFIX_RE = re.compile(r"^wxid_[0-9A-Za-z_\-]{3,40}:\n")


def _jdefault(o):
    if isinstance(o, bytes):
        return o.decode("utf-8", "replace")
    return str(o)


def export_message_db(db_path, contacts, hash_map, self_id, out_dir, exclude_groups=False, collect=None,
                      privacy_files=False, privacy_names=False, idx_counter=None, mapping=None):
    """导出单个 message db 里所有会话。返回统计列表。"""
    db = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    db.text_factory = bytes
    id2name = {}
    try:
        for rowid, name in db.execute("select rowid, user_name from Name2Id"):
            id2name[rowid] = (name or b"").decode("utf-8", "replace")
    except sqlite3.Error:
        pass
    tabs = [(t[0].decode() if isinstance(t[0], bytes) else t[0])
            for t in db.execute("select name from sqlite_master where type='table' and name like 'Msg_%'")]
    stats = []
    os.makedirs(os.path.join(out_dir, "jsonl"), exist_ok=True)
    os.makedirs(os.path.join(out_dir, "txt"), exist_ok=True)
    members = contacts.get("__member__", {})

    from_biz_db = "biz_message" in os.path.basename(db_path)
    for t in tabs:
        h = t[4:]
        talker = hash_map.get(h, f"unknown_{h[:8]}")
        is_group = talker.endswith(GROUP_SUFFIX)
        if is_group and exclude_groups:
            continue                      # 用户只要单聊：整表跳过，省时间也省空间
        if idx_counter is not None:
            idx_counter[0] += 1
        seq = idx_counter[0] if idx_counter else 0
        info = contacts.get(talker) or {}
        disp = info.get("name") or talker
        rows = db.execute(
            f"select local_id, local_type, real_sender_id, create_time, message_content, source "
            f"from [{t}] order by create_time, local_id"
        )
        stem = f"c{seq:03d}" if privacy_files else safe_name(talker)
        jf = open(os.path.join(out_dir, "jsonl", f"{stem}.jsonl"), "w", encoding="utf-8")
        tf = open(os.path.join(out_dir, "txt", f"{stem}.txt"), "w", encoding="utf-8")
        tf.write(f"# 会话: {disp}  ({talker})  群聊={is_group}\n")
        n = first = last = 0
        html_msgs = [] if collect is not None else None
        try:
            rows_iter = list(rows)
        except sqlite3.Error as e:      # 单表损坏不该拖垮整库导出
            print(f"   (表 {t} 读取失败，跳过: {e})")
            jf.close(); tf.close()
            continue
        for local_id, mtype, sid, ctime, raw, source in rows_iter:
            text, was_zstd = decode_content(raw)
            if source:
                s, _ = decode_content(source)
                source = s
            base_type = mtype & 0xFFFFFFFF
            subtype = mtype >> 32
            sender = id2name.get(sid) or ""
            if not sender and is_group:
                sender = talker
            if not sender:
                # 单聊里 sender 为空：10000 系统消息不算“我”，其余视为自己发的
                is_self = base_type != 10000
                sender = self_id if is_self else ""
            else:
                is_self = sender == self_id and bool(self_id)
            sender_name = "我" if is_self else (
                "系统" if not sender else
                members.get(f"{talker}|{sender}") or (contacts.get(sender) or {}).get("name") or sender
            )
            ts = _fmt_time(ctime)
            if is_group and base_type == 1:
                text = GROUP_PREFIX_RE.sub("", text)
            body = render(base_type, text)
            jf.write(json.dumps({
                "talker": talker, "talker_name": disp, "is_chatroom": is_group,
                "sender": sender, "sender_name": sender_name, "is_self": is_self,
                "time": ts, "timestamp": ctime, "type": base_type, "sub_type": subtype,
                "raw_type": mtype,
                "type_name": TYPE_NAME.get(base_type, str(base_type)),
                "content": text if base_type in (1, 10000) else body,
                "rendered": body, "zstd": was_zstd, "local_id": local_id, "source": source,
            }, ensure_ascii=False, default=_jdefault) + "\n")
            tf.write(f"[{ts}] {sender_name}: {body}\n")
            if html_msgs is not None:
                html_msgs.append([int(ctime), 1 if is_self else 0, base_type, body])
            n += 1
            first = first or ctime
            last = ctime
        jf.close()
        tf.close()
        if mapping is not None and n:
            mapping.append({"file": stem, "talker": talker, "name": disp,
                            "kind": "group" if is_group else ("service" if is_service_talker(talker, from_biz_db) else "direct"),
                            "count": n, "first": _fmt_time(first, "%Y-%m-%d") if n else "",
                            "last": _fmt_time(last, "%Y-%m-%d %H:%M") if n else ""})
        if collect is not None and n:
            collect.append({
                "id": talker, "name": disp, "kind": "group" if is_group
                else ("service" if is_service_talker(talker, from_biz_db) else "direct"),
                "count": n, "first": first, "last": last, "msgs": html_msgs,
            })
        stats.append({
            "talker": talker, "name": disp, "is_chatroom": is_group, "count": n,
            "first": _fmt_time(first, "%Y-%m-%d") if n else "",
            "last": _fmt_time(last, "%Y-%m-%d %H:%M") if n else "",
            "table": t,
        })
        if privacy_names:
            print(f"  c{seq:03d}   {n:>7} 条")          # 不显示会话名/昵称
        else:
            print(f"  {disp[:24]:<26} {n:>7} 条  {stats[-1]['first']} → {stats[-1]['last']}")
    db.close()
    return stats


def guess_self_id(*paths):
    """从 db_storage 的父目录名（形如 wxid_xxx_56eb）推断本机账号。"""
    for p in paths:
        if not p:
            continue
        p = os.path.abspath(p)
        for cand in (os.path.basename(p), os.path.basename(os.path.dirname(p))):
            m = re.match(r"(wxid_[0-9A-Za-z_\-]{4,40})_[0-9a-fA-F]{4,8}$", cand)
            if m:
                return m.group(1)
    return ""


# ---------------------------------------------------------------
# 单文件 HTML 查看器：无外部依赖、离线可开、可搜索
# ---------------------------------------------------------------
VIEWER_TMPL = r"""<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>微信聊天记录 · __TITLE__</title>
<style>
  :root{--bg:#f5f6f8;--panel:#fff;--line:#e6e8ec;--txt:#20242b;--dim:#8a919c;--self:#95ec69;--other:#fff;--accent:#0b7a3b}
  *{box-sizing:border-box}
  html,body{height:100%;margin:0}
  body{font:14px/1.55 "Microsoft YaHei","PingFang SC","Noto Sans CJK SC",system-ui,sans-serif;color:var(--txt);background:var(--bg);display:flex;overflow:hidden}
  aside{width:300px;min-width:300px;background:var(--panel);border-right:1px solid var(--line);display:flex;flex-direction:column}
  .hd{padding:12px 14px 8px;border-bottom:1px solid var(--line)}
  .hd h1{font-size:15px;margin:0 0 4px}
  .hd .meta{color:var(--dim);font-size:12px;line-height:1.5}
  .search{padding:8px 10px;border-bottom:1px solid var(--line)}
  .search input{width:100%;padding:7px 9px;border:1px solid var(--line);border-radius:6px;font-size:13px;outline:none}
  .search input:focus{border-color:var(--accent)}
  #list{flex:1;overflow:auto}
  .sec{padding:8px 12px 4px;color:var(--dim);font-size:12px;background:#fafbfc;position:sticky;top:0}
  .item{padding:8px 12px;border-bottom:1px solid #f2f3f5;cursor:pointer}
  .item:hover{background:#f7f9fa}
  .item.on{background:#eef7f0;box-shadow:inset 3px 0 0 var(--accent)}
  .item .n{display:flex;justify-content:space-between;gap:8px}
  .item .name{font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .item .cnt{color:var(--dim);font-size:12px;flex:0 0 auto}
  .item .sub{color:var(--dim);font-size:12px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  main{flex:1;display:flex;flex-direction:column;min-width:0}
  .top{padding:10px 16px;border-bottom:1px solid var(--line);background:var(--panel);display:flex;justify-content:space-between;align-items:baseline;gap:10px}
  .top h2{margin:0;font-size:15px}
  .top .meta{color:var(--dim);font-size:12px;flex:0 0 auto}
  #msgs{flex:1;overflow:auto;padding:14px 16px 60px}
  .day{text-align:center;color:var(--dim);font-size:12px;margin:14px 0 10px}
  .row{display:flex;margin-bottom:8px}
  .row.self{justify-content:flex-end}
  .bub{max-width:min(680px,78%);padding:7px 10px;border-radius:8px;background:var(--other);border:1px solid var(--line);white-space:pre-wrap;word-break:break-word}
  .row.self .bub{background:var(--self);border-color:#7fd455}
  .who{font-size:12px;color:var(--dim);margin-bottom:2px}
  .tag{display:inline-block;padding:0 5px;border-radius:4px;background:#eef0f3;color:#5b6472;font-size:12px;margin-right:4px}
  .t{color:var(--dim);font-size:11px;align-self:flex-end;margin:0 6px}
  .hint{color:var(--dim);text-align:center;padding:24px}
  .more{display:block;margin:10px auto;padding:6px 14px;border:1px solid var(--line);background:#fff;border-radius:6px;cursor:pointer;color:#4a5261}
  .hit{padding:8px 12px;border-bottom:1px solid #f2f3f5;cursor:pointer}
  .hit:hover{background:#f7f9fa}
  .hit .h{font-size:12px;color:var(--dim);display:flex;justify-content:space-between;gap:8px}
  mark{background:#ffe9a8;padding:0 2px}
</style>
</head>
<body>
<aside>
  <div class="hd">
    <h1>微信聊天记录</h1>
    <div class="meta" id="stat"></div>
  </div>
  <div class="search"><input id="q" type="search" placeholder="搜会话名 / 消息内容…"></div>
  <div id="list"></div>
</aside>
<main>
  <div class="top"><h2 id="title">选择左侧会话</h2><div class="meta" id="cmeta"></div></div>
  <div id="msgs"><div class="hint">数据全部在本文件里，不联网。群聊按设置已排除。<br>左侧点会话开始看，或用上面的搜索框搜内容。</div></div>
</main>
<script id="data" type="application/json">__DATA__</script>
<script>
(function(){
  var D=JSON.parse(document.getElementById('data').textContent);
  var KIND={direct:'单聊',service:'服务号 / 公众号',group:'群聊'};
  var $=function(id){return document.getElementById(id)};
  var cur=null,shown=0,lc=null;

  var totalMsgs=D.convs.reduce(function(a,c){return a+c.msgs.length},0);
  var direct=D.convs.filter(function(c){return c.kind==='direct'}).length;
  $('stat').textContent='共 '+D.convs.length+' 个会话 · '+totalMsgs.toLocaleString()+' 条 · 单聊 '+direct+' 个\n'+D.generated;

  function fmt(ts){var d=new Date(ts*1000);function p(n){return (n<10?'0':'')+n}
    return d.getFullYear()+'-'+p(d.getMonth()+1)+'-'+p(d.getDate())+' '+p(d.getHours())+':'+p(d.getMinutes())}
  function day(ts){var d=new Date(ts*1000);function p(n){return (n<10?'0':'')+n}
    return d.getFullYear()+'年'+p(d.getMonth()+1)+'月'+p(d.getDate())+'日'}
  function esc(s){return s.replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}

  function drawList(hits){
    var box=$('list');box.innerHTML='';
    if(hits){var t=document.createElement('div');t.className='sec';t.textContent='内容匹配 '+hits.length+' 条';box.appendChild(t);
      hits.slice(0,300).forEach(function(h){
        var el=document.createElement('div');el.className='hit';
        el.innerHTML='<div class="h"><span>'+esc(h.name)+'</span><span>'+fmt(h.ts)+'</span></div><div>'+h.html+'</div>';
        el.onclick=function(){open(h.cid,h.idx)};
        box.appendChild(el)});
      return}
    ['direct','service','group'].forEach(function(k){
      var cs=D.convs.filter(function(c){return c.kind===k});
      if(!cs.length)return;
      cs.sort(function(a,b){return b.last-a.last});
      var s=document.createElement('div');s.className='sec';s.textContent=KIND[k]+' · '+cs.length;box.appendChild(s);
      cs.forEach(function(c){
        var el=document.createElement('div');el.className='item'+(cur&&cur.id===c.id?' on':'');el.dataset.id=c.id;
        var sub=c.msgs.length?c.msgs[c.msgs.length-1][3]:'';
        el.innerHTML='<div class="n"><span class="name">'+esc(c.name)+'</span><span class="cnt">'+c.count+'</span></div><div class="sub">'+esc(sub.slice(0,40))+'</div>';
        el.onclick=function(){open(c.id,0)};
        box.appendChild(el)})});
  }

  function head(){var c=cur;
    $('title').textContent=c.name;
    $('cmeta').textContent=c.count+' 条 · '+fmt(c.first)+' → '+fmt(c.last)+'  ·  '+c.id}

  function loadMore(){
    var box=$('msgs'),c=cur,end=Math.min(shown+300,c.msgs.length),lastDay='';
    if(shown>0){var pm=c.msgs[shown-1];lastDay=day(pm[0])}
    for(var i=shown;i<end;i++){
      var m=c.msgs[i],d=day(m[0]);
      if(d!==lastDay){var h=document.createElement('div');h.className='day';h.textContent=d;box.appendChild(h);lastDay=d}
      var r=document.createElement('div');r.className='row'+(m[1]?' self':'');r.id='m'+i;
      var tag=m[2]===1?'':'<span class="tag">'+esc(TYPENAME(m[2]))+'</span>';
      var html='<div class="who">'+(m[1]?'我':esc(c.name))+'</div><div class="bub">'+tag+esc(m[3])+'</div><div class="t">'+fmt(m[0]).slice(11)+'</div>';
      r.innerHTML=html;box.appendChild(r)}
    shown=end;
    var old=box.querySelector('.more');if(old)old.remove();
    if(shown<c.msgs.length){var b=document.createElement('button');b.className='more';b.textContent='继续加载（还有 '+(c.msgs.length-shown)+' 条）';
      b.onclick=function(){var before=box.scrollTop;loadMore();box.scrollTop=before};box.appendChild(b)}
  }
  var T={1:'文本',3:'图片',34:'语音',43:'视频',47:'表情',48:'位置',49:'链接/文件/引用',50:'音视频通话',10000:'系统'};
  function TYPENAME(x){return T[x]||('类型'+x)}

  function open(cid,idx){
    var c=null;D.convs.forEach(function(x){if(x.id===cid)c=x});
    if(!c)return;cur=c;shown=0;
    $('msgs').innerHTML='';head();
    var box=$('msgs');
    box.onscroll=function(){if(box.scrollHeight-box.scrollTop-box.clientHeight<120&&shown<cur.msgs.length)loadMore()};
    loadMore();
    if(idx){while(shown<=idx&&shown<cur.msgs.length)loadMore();
      var el=document.getElementById('m'+idx);if(el){box.scrollTop=el.offsetTop-80;el.querySelector('.bub').style.outline='2px solid #ffb300'}}
    drawList();
  }

  var timer=null;
  $('q').oninput=function(){
    clearTimeout(timer);
    timer=setTimeout(function(){
      var q=$('q').value.trim().toLowerCase();
      if(!q){drawList();return}
      if(lc===null)lc=D.convs.map(function(c){return c.msgs.map(function(m){return m[3].toLowerCase()})});
      var hits=[],byName=0;
      D.convs.forEach(function(c,ci){
        if(c.name.toLowerCase().indexOf(q)>=0||c.id.toLowerCase().indexOf(q)>=0)byName++;
        var arr=lc[ci];
        for(var i=0;i<arr.length&&hits.length<300;i++){
          var p=arr[i].indexOf(q);
          if(p<0)continue;
          var txt=c.msgs[i][3],s=Math.max(0,p-30),e=Math.min(txt.length,p+q.length+40);
          hits.push({cid:c.id,idx:i,name:c.name,ts:c.msgs[i][0],
            html:(s>0?'…':'')+esc(txt.slice(s,p))+'<mark>'+esc(txt.slice(p,p+q.length))+'</mark>'+esc(txt.slice(p+q.length,e))+(e<txt.length?'…':'')});
        }});
      if(byName&&!hits.length){drawList();var s=document.createElement('div');s.className='sec';s.textContent='会话名匹配 '+byName+' 个（见下）';$('list').insertBefore(s,$('list').firstChild);return}
      drawList(hits);});
  };

  drawList();
})();
</script>
</body>
</html>
"""


def write_viewer(out_dir: str, self_id: str, convs: list) -> str:
    """把导出的会话写成一个单文件 HTML（离线、可搜、双击即看）。"""
    convs = sorted(convs, key=lambda c: (c["kind"] != "direct", -c["last"]))
    payload = {
        "self_id": self_id,
        "generated": datetime.datetime.now().strftime("导出时间 %Y-%m-%d %H:%M"),
        "convs": convs,
    }
    data = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
    title = f"{len(convs)} 个会话"
    html = VIEWER_TMPL.replace("__TITLE__", title).replace("__DATA__", data)
    path = os.path.join(out_dir, "聊天记录.html")
    with open(path, "w", encoding="utf-8") as f:
        f.write(html)
    return path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--decrypted", default="decrypted")
    ap.add_argument("--out", default="export")
    ap.add_argument("--self-id", default=os.environ.get("WX_SELF_ID") or "",
                    help="本机账号 wxid（缺省从目录名推断）")
    ap.add_argument("--exclude-groups", action="store_true", help="不导出群聊（只要单聊）")
    ap.add_argument("--no-html", action="store_true", help="不生成单文件 HTML 查看器")
    ap.add_argument("--privacy", action="store_true",
                    help="隐私模式：文件名序号化(c001…)并写 mapping.json；终端不打印会话名")
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)
    if not args.self_id:
        args.self_id = guess_self_id(args.decrypted, os.getcwd())
    if not args.self_id:
        print("!! 未能确定本机 wxid，1:1 聊天里自己发的消息可能被误标为对方；请用 --self-id 指定")

    contact_db = os.path.join(args.decrypted, "contact", "contact.db")
    session_db = os.path.join(args.decrypted, "session", "session.db")
    msg_dbs = [os.path.join(args.decrypted, "message", f) for f in ("message_0.db", "biz_message_0.db")]
    msg_dbs = [d for d in msg_dbs if os.path.exists(d)]
    contacts = load_contacts(contact_db)
    hash_map = build_hash_map(contact_db, msg_dbs, session_db)
    n_contacts = sum(1 for k in contacts if k != "__member__")
    print(f"联系人 {n_contacts} 个, md5 索引 {len(hash_map)} 个, 消息库 {len(msg_dbs)} 个")

    all_stats = []
    convs = []
    mapping = []
    idx_counter = [0]
    t0 = time.time()
    for db in msg_dbs:
        print(f"== {os.path.basename(db)} ==")
        all_stats += export_message_db(db, contacts, hash_map, args.self_id, args.out,
                                       exclude_groups=args.exclude_groups, collect=convs,
                                       privacy_files=args.privacy, privacy_names=args.privacy,
                                       idx_counter=idx_counter, mapping=mapping)
    all_stats.sort(key=lambda s: -s["count"])
    total = sum(s["count"] for s in all_stats)
    if mapping:
        with open(os.path.join(args.out, "mapping.json"), "w", encoding="utf-8") as f:
            json.dump({"note": "file 字段是文件名前缀，其余是会话信息（若文件名已序号化，用它对照）",
                       "items": mapping}, f, ensure_ascii=False, indent=1)
    if not args.no_html and convs:
        viewer = write_viewer(args.out, args.self_id, convs)
        print(f"打开看: {viewer}（单文件，双击用浏览器打开）")
    idx = {"generated_at": datetime.datetime.now().isoformat(timespec="seconds"),
           "self_id": args.self_id, "conversations": all_stats, "total_messages": total}
    with open(os.path.join(args.out, "index.json"), "w", encoding="utf-8") as f:
        json.dump(idx, f, ensure_ascii=False, indent=1)
    print(f"\n总计 {total} 条 / {len(all_stats)} 个会话，耗时 {time.time() - t0:.1f}s，输出 {args.out}/")
    if total == 0:
        raise SystemExit(1)   # 没导出任何消息 = 失败，别让调用方以为成功


if __name__ == "__main__":
    main()
