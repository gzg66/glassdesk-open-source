﻿<#
  微信 4.1+ (Windows) 聊天记录一键提取 —— Windows 原生版（不需要 WSL）

  做的事：只读扫描微信进程内存取密钥 → 解密本机微信数据库 → 导出聊天记录 → 打包 zip
  不会：注入进程 / 修改微信文件 / 联网上传 / 后台驻留 / 删除痕迹

  用法（在一个正常可见的控制台里跑）：
    .\run.ps1
    .\run.ps1 -DbDir "C:\Users\xx\Documents\xwechat_files\wxid_xxx_56eb\db_storage"
    .\run.ps1 -WithKeys          # 额外把数据库密钥写进包（默认不写）
    .\run.ps1 -InstallDeps       # 若解压 zstd 失败，先 pip install zstandard

  前置：微信 4.x 已登录并在运行；建议右键「以管理员身份运行」PowerShell。
#>
[CmdletBinding()]
param(
    [string]$DbDir = "",
    [string]$OutRoot = "",
    [string]$Python = "",
    [string]$SelfId = "",
    [switch]$WithKeys,
    [switch]$IncludeGroups,
    [switch]$ShowNames,
    [switch]$InstallDeps
)

$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $here
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch { }

function Say([string]$m) { Write-Host $m }
function Die([string]$m) { Write-Host "!! $m"; exit 1 }

# 原生程序（exe）会把 stderr 当错误，Stop 模式下会抛异常 —— 单独包一层
# 输出直接送到控制台（不进入函数返回值，否则调用方拿到的是文字而非退出码），
# 退出码放 $script:LastNativeCode
function Invoke-Native {
    param([string]$Exe, [string[]]$ArgList)
    $prev = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        & $Exe @ArgList 2>&1 | Out-Host
        $script:LastNativeCode = $LASTEXITCODE
    }
    finally { $ErrorActionPreference = $prev }
}

Say "工作目录: $here"

# ---------- 1. 找 Python ----------
function Resolve-Python {
    param([string]$Explicit)
    $cands = @()
    if ($Explicit) { $cands += $Explicit }
    else {
        # 优先用随包携带的便携 Python（目标机什么都不用装）
        $cands += @("$here\python\python.exe", "$here\winpy\python.exe")
        $cands += @('py -3', 'python', 'python3')
        $cands += (Get-ChildItem "$env:LOCALAPPDATA\Programs\Python\Python*\python.exe" -ErrorAction SilentlyContinue | ForEach-Object FullName)
        $cands += (Get-ChildItem "$env:ProgramFiles\Python*\python.exe" -ErrorAction SilentlyContinue | ForEach-Object FullName)
    }
    foreach ($c in $cands) {
        try {
            $prev = $ErrorActionPreference
            $ErrorActionPreference = 'Continue'
            try {
                $exe = $c
                if ($c -eq 'py -3') {
                    $exe = (& py -3 -c "import sys;print(sys.executable)" 2>$null)
                    if ($LASTEXITCODE -ne 0) { continue }
                }
                $ver = (& $exe -c "import sys;print('%d.%d' % sys.version_info[:2])" 2>$null)
                $ok = ($LASTEXITCODE -eq 0)
                if (-not $ok -or -not $ver) { continue }
            } finally { $ErrorActionPreference = $prev }
            $p = $ver.Split('.')
            if ([int]$p[0] -lt 3 -or ([int]$p[0] -eq 3 -and [int]$p[1] -lt 8)) { continue }
            return @{ Exe = $exe; Ver = $ver }
        } catch { continue }
    }
    return $null
}

$py = Resolve-Python -Explicit $Python
if (-not $py) { Die "找不到可用的 Python 3.8+（装一个 python.org 版，或用 -Python 指定路径）。" }
Say "Python: $($py.Exe)  ($($py.Ver))"

if ($InstallDeps) {
    Say "安装可选依赖 zstandard ..."
    $script:LastNativeCode = 0
    Invoke-Native $py.Exe @('-m', 'pip', 'install', 'zstandard')
    if ($script:LastNativeCode -ne 0) { Say "   !! pip 安装失败（退出码 $script:LastNativeCode），继续；若之后 zstd 解压失败请手动装" }
}

# ---------- 2. 找数据库目录 ----------
if (-not $DbDir) {
    foreach ($r in @("$env:USERPROFILE\Documents\xwechat_files", "$env:USERPROFILE\Documents\WeChat Files")) {
        if (-not (Test-Path $r)) { continue }
        $found = @(Get-ChildItem $r -Directory -ErrorAction SilentlyContinue |
                   ForEach-Object { Join-Path $_.FullName 'db_storage' } |
                   Where-Object { Test-Path $_ })
        if ($found.Count -eq 1) { $DbDir = $found[0]; break }
        if ($found.Count -gt 1) {
            Say "检测到 $($found.Count) 个账号目录（含历史残留），交给程序按"当前登录"自动挑选"
            $DbDir = $r; break
        }
    }
}
if (-not $DbDir -or -not (Test-Path $DbDir)) { Die "找不到微信 db_storage 目录，请用 -DbDir 指定。" }
Say "数据目录: $DbDir"


# ---------- 3. 微信在跑吗 ----------
$wx = @(Get-Process -Name Weixin -ErrorAction SilentlyContinue)
if ($wx.Count -eq 0) { Die "微信没在运行。先登录 Windows 微信，再跑本脚本（密钥只在登录期间驻留内存）。" }
$main = $wx | Sort-Object WorkingSet64 -Descending | Select-Object -First 1
Say "微信进程: pid=$($main.Id)  $([int]($main.WorkingSet64 / 1MB))MB"

# ---------- 4. 取密钥 ----------
if (-not (Test-Path .\wxkey.exe)) { Die "缺 wxkey.exe（编译：csc /nologo /optimize+ /platform:x64 /out:wxkey.exe wxkey.cs）" }
Say "`n== [1/4] 扫描微信进程内存取密钥 =="
$prev = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
& "$here\wxkey.exe" scan 2>&1 | Out-File -FilePath scan.log -Encoding utf8
$rc = $LASTEXITCODE
$ErrorActionPreference = $prev
# 日志里有能解开全部微信库的密钥，只留给当前用户；失败必须说一声
function Restrict-File([string]$Path) {
    try {
        $out = & icacls "$Path" /inheritance:r /grant:r "$($env:USERNAME):(F)" 2>&1
        if ($LASTEXITCODE -ne 0) { Say "   !! 收紧 $([IO.Path]::GetFileName($Path)) 权限失败（icacls 退出码 $LASTEXITCODE）：$out" }
    } catch { Say "   !! 收紧 $([IO.Path]::GetFileName($Path)) 权限时出错：$_" }
}
Restrict-File "$here\scan.log"
$cands = @(Select-String -Path scan.log -Pattern '^\[CAND\]' -ErrorAction SilentlyContinue).Count
if ($cands -eq 0) {
    Say "!! 没扫到候选密钥（wxkey 退出码 $rc）。末尾几行："
    Get-Content scan.log -Tail 5 | ForEach-Object { Say "    $_" }
    Die "确认微信已登录，或改用管理员身份重跑。"
}
Say "   候选密钥 $cands 条（详见 scan.log）"

# ---------- 5. 解密 + 导出 ----------
Say "`n== [2/4] 解密数据库 =="
if (Test-Path decrypted) { Remove-Item decrypted -Recurse -Force }
$script:LastNativeCode = 0
Invoke-Native $py.Exe @('wxdecrypt.py', $DbDir, 'scan.log', 'decrypted')
if ($script:LastNativeCode -ne 0) { Die "解密失败（退出码 $script:LastNativeCode）" }

# 账号目录以解密阶段实际选中的为准（多账号残留时会择优）
$accountDir = Split-Path -Parent $DbDir
if (Test-Path chosen_dbdir.txt) {
    $chosen = (Get-Content chosen_dbdir.txt -Raw).Trim()
    if ($chosen) { $accountDir = Split-Path -Parent $chosen; Say "当前登录账号目录: $chosen" }
}
$selfId = if ($SelfId) { $SelfId } else { (Split-Path -Leaf $accountDir) -replace '_[0-9a-fA-F]{4,8}$', '' }
$selfArg = @()
if ($selfId -match '^wxid_[0-9A-Za-z_\-]+$') {
    $selfArg = @('--self-id', $selfId); Say "本机账号: $selfId"
} else {
    if ($SelfId) { Say "!! -SelfId 传的值 '$SelfId' 不像 wxid（应以 wxid_ 开头），已忽略" }
    Say "本机账号：未能识别（1:1 聊天里自己发的消息可能被误标，可用 -SelfId 手动指定）"
}

Say "`n== [3/4] 导出聊天记录 =="
if (Test-Path export) { Remove-Item export -Recurse -Force }
$exportArgs = @('wxexport.py', '--decrypted', 'decrypted', '--out', 'export', '--privacy') + $selfArg
if (-not $IncludeGroups) { $exportArgs += '--exclude-groups'; Say "（默认不含群聊；要群聊加 -IncludeGroups）" }
if ($ShowNames) { $exportArgs = $exportArgs | Where-Object { $_ -ne '--privacy' }; Say "（-ShowNames：终端会打印会话名）" }
$script:LastNativeCode = 0
Invoke-Native $py.Exe $exportArgs
if ($script:LastNativeCode -ne 0) { Die "导出失败（退出码 $script:LastNativeCode）" }

# ---------- 6. 打包 ----------
Say "`n== [4/4] 打包 =="
if ($OutRoot) {
    if (-not (Test-Path $OutRoot)) { New-Item -ItemType Directory -Path $OutRoot -Force | Out-Null }
}
$stamp = Get-Date -Format 'yyyyMMdd-HHmm'
$base = if ($OutRoot) { $OutRoot } else { $here }
$pkg = Join-Path $base "wechat-chatlog-$stamp"
$zip = "$pkg.zip"
foreach ($p in @($pkg, $zip)) { if (Test-Path $p) { Remove-Item $p -Recurse -Force } }
New-Item -ItemType Directory -Path $pkg | Out-Null
Copy-Item export "$pkg\export" -Recurse
# 包内说明直接沿用仓库里那份，避免两处文案各说各话
Copy-Item "$here\README.md" "$pkg\README.md"
if ($WithKeys) {
    Select-String -Path scan.log -Pattern '^\[CAND\]' | ForEach-Object { $_.Line } | Set-Content "$pkg\keys.txt" -Encoding ascii
    Restrict-File "$pkg\keys.txt"
    Say "   !! keys.txt 能解开本机全部微信数据库，转发/上传前务必删除"
}
# 把 HTML 也放一份在包根目录，解压后直接双击就能看
$viewer = Join-Path "export" '聊天记录.html'
if (Test-Path $viewer) { Copy-Item $viewer (Join-Path $pkg '聊天记录.html') }
# 用自带 Python 打包：zip 内路径用 / 分隔（PS 的 Compress-Archive 写 \，跨平台解压会错），且走 ZIP64
$script:LastNativeCode = -1
Invoke-Native $py.Exe @('mkzip.py', $pkg, $zip)
if ($script:LastNativeCode -ne 0 -or -not (Test-Path $zip)) {
    Say "   （mkzip.py 不可用，回退 Compress-Archive）"
    Compress-Archive -Path "$pkg\*" -DestinationPath $zip -CompressionLevel Optimal
}
Say "   打包完成: $zip  ($([int]((Get-Item $zip).Length / 1MB))MB)"
Say "`n注: scan.log 含数据库密钥，别把这个工作目录整体外发。"
Say "== 全部完成"
