#!/usr/bin/env python3
"""微信 4.1 (Windows) SQLCipher4 解密 + WAL 合并。纯离线，对已 dump 出的候选密钥做校验。"""
import glob
import hashlib
import hmac
import os
import re
import struct
import sys

try:  # Windows 控制台或输出重定向时，避免中文/特殊字符捅 UnicodeEncodeError
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


# ---------------------------------------------------------------
# AES-256-CBC 解密后端
#   Windows  : 系统 CNG（bcrypt.dll），零第三方依赖
#   其他平台  : cryptography（仅开发/测试方便）
# ---------------------------------------------------------------
class _CngAes:
    """Windows CNG 的 AES-256-CBC 解密（无 padding）；复用 provider 与密钥句柄。"""

    def __init__(self):
        import ctypes
        import ctypes.wintypes as wt
        self.ctypes = ctypes
        self.wt = wt
        self.bcrypt = ctypes.WinDLL("bcrypt")
        b = self.bcrypt
        b.BCryptOpenAlgorithmProvider.argtypes = [ctypes.POINTER(wt.HANDLE), ctypes.c_wchar_p, ctypes.c_wchar_p, ctypes.c_ulong]
        b.BCryptSetProperty.argtypes = [wt.HANDLE, ctypes.c_wchar_p, ctypes.c_char_p, ctypes.c_ulong, ctypes.c_ulong]
        b.BCryptGenerateSymmetricKey.argtypes = [wt.HANDLE, ctypes.POINTER(wt.HANDLE), ctypes.c_char_p, ctypes.c_ulong, ctypes.c_char_p, ctypes.c_ulong, ctypes.c_ulong]
        b.BCryptDecrypt.argtypes = [wt.HANDLE, ctypes.c_char_p, ctypes.c_ulong, ctypes.c_void_p, ctypes.c_char_p, ctypes.c_ulong, ctypes.c_char_p, ctypes.c_ulong, ctypes.POINTER(ctypes.c_ulong), ctypes.c_ulong]
        b.BCryptDestroyKey.argtypes = [wt.HANDLE]
        b.BCryptCloseAlgorithmProvider.argtypes = [wt.HANDLE, ctypes.c_ulong]
        self.h_alg = wt.HANDLE()
        st = b.BCryptOpenAlgorithmProvider(ctypes.byref(self.h_alg), "AES", None, 0)
        if st != 0:
            raise OSError(f"BCryptOpenAlgorithmProvider failed: {st:#x}")
        mode = "ChainingModeCBC\x00".encode("utf-16-le")
        st = b.BCryptSetProperty(self.h_alg, "ChainingMode", mode, len(mode), 0)
        if st != 0:
            raise OSError(f"BCryptSetProperty(ChainingModeCBC) failed: {st:#x}")
        self._keys = {}

    def _key_handle(self, key: bytes):
        h = self._keys.get(key)
        if h is not None:
            return h
        hk = self.wt.HANDLE()
        st = self.bcrypt.BCryptGenerateSymmetricKey(
            self.h_alg, self.ctypes.byref(hk), None, 0, key, len(key), 0)
        if st != 0:
            raise OSError(f"BCryptGenerateSymmetricKey failed: {st:#x}")
        if len(self._keys) >= 8:  # 句柄不无限增长
            old = next(iter(self._keys))
            self.bcrypt.BCryptDestroyKey(self._keys.pop(old))
        self._keys[key] = hk
        return hk

    def decrypt(self, key: bytes, iv: bytes, data: bytes) -> bytes:
        ctypes = self.ctypes
        hk = self._key_handle(key)
        iv_buf = ctypes.create_string_buffer(iv, len(iv))
        out = ctypes.create_string_buffer(len(data))
        done = ctypes.c_ulong(0)
        st = self.bcrypt.BCryptDecrypt(
            hk, data, len(data), None, iv_buf, len(iv),
            out, len(out), ctypes.byref(done), 0)
        if st != 0:
            raise OSError(f"BCryptDecrypt failed: {st:#x}")
        return out.raw[: done.value]


class _CryptoAes:
    def __init__(self):
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes  # noqa: F401
        self._Cipher = Cipher

    def decrypt(self, key: bytes, iv: bytes, data: bytes) -> bytes:
        from cryptography.hazmat.primitives.ciphers import algorithms, modes
        d = self._Cipher(algorithms.AES(key), modes.CBC(iv)).decryptor()
        return d.update(data) + d.finalize()


_BACKEND = None


def _backend():
    global _BACKEND
    if _BACKEND is None:
        _BACKEND = _CngAes() if sys.platform == "win32" else _CryptoAes()
    return _BACKEND


def aes_cbc_dec(key: bytes, iv: bytes, data: bytes) -> bytes:
    """AES-256-CBC 解密（无 padding），自动选后端。"""
    return _backend().decrypt(key, iv, data)

PAGE = 4096
RESERVE = 80
ENC_LEN = PAGE - RESERVE          # 4016
IV_OFF = ENC_LEN                  # 4016..4032
HMAC_OFF = PAGE - 64              # 4032..4096
SQLITE_HDR = b"SQLite format 3\x00"


def verify_key(enc_key: bytes, page1: bytes) -> bool:
    if len(page1) < PAGE:
        return False
    salt = page1[:16]
    mac_key = hashlib.pbkdf2_hmac("sha512", enc_key, bytes(b ^ 0x3A for b in salt), 2, 32)
    h = hmac.new(mac_key, page1[16:HMAC_OFF], hashlib.sha512)
    h.update(struct.pack("<I", 1))
    return h.digest() == page1[HMAC_OFF:PAGE]


def decrypt_page(enc_key: bytes, page: bytes, pgno: int) -> bytes:
    page = page + b"\x00" * (PAGE - len(page)) if len(page) < PAGE else page
    iv = page[IV_OFF:IV_OFF + 16]
    if pgno == 1:
        body = aes_cbc_dec(enc_key, iv, page[16:ENC_LEN])
        return SQLITE_HDR + body + b"\x00" * RESERVE
    return aes_cbc_dec(enc_key, iv, page[:ENC_LEN]) + b"\x00" * RESERVE


def wal_checksum(data: bytes, s1: int, s2: int, big_endian: bool):
    """SQLite WAL 校验和：每 8 字节拆成两个 u32，s1 += x + s2; s2 += y + s1。"""
    fmt = ">II" if big_endian else "<II"
    for i in range(0, len(data) - 7, 8):
        x, y = struct.unpack(fmt, data[i:i + 8])
        s1 = (s1 + x + s2) & 0xFFFFFFFF
        s2 = (s2 + y + s1) & 0xFFFFFFFF
    return s1, s2


def wal_frames(wal: bytes):
    """按 SQLite 规范解析 WAL，只产出通过 salt + checksum 校验的帧 (pgno, page)。"""
    if len(wal) < 32:
        return
    magic, _ver, pgsz, _seq, salt1, salt2, hck1, hck2 = struct.unpack(">8I", wal[:32])
    if magic not in (0x377F0682, 0x377F0683) or _ver != 3007000 or pgsz != PAGE:
        return
    big_endian = (magic & 1) == 1
    c1, c2 = wal_checksum(wal[:24], 0, 0, big_endian)
    if (c1, c2) != (hck1, hck2):
        return  # WAL 头校验失败 → 视为陈旧 WAL，整段忽略
    off, prev = 32, (hck1, hck2)
    while off + 24 + PAGE <= len(wal):
        fh = wal[off:off + 24]
        pgno, _dbsize, fs1, fs2, fc1, fc2 = struct.unpack(">6I", fh)
        if fs1 != salt1 or fs2 != salt2 or pgno == 0:
            return  # 帧 salt 不匹配 → 后续帧无效，停止
        c1, c2 = wal_checksum(fh[:8], prev[0], prev[1], big_endian)
        c1, c2 = wal_checksum(wal[off + 24:off + 24 + PAGE], c1, c2, big_endian)
        if (c1, c2) != (fc1, fc2):
            return  # 校验和不符 → 截断（未提交的尾部）
        prev = (c1, c2)
        yield pgno, wal[off + 24:off + 24 + PAGE]
        off += 24 + PAGE


def decrypt_db(db_path: str, out_path: str, enc_key: bytes, verbose: bool = False) -> bool:
    """逐页流式解密（不把整个库读进内存），再按规范重放 WAL。"""
    size = os.path.getsize(db_path)
    if size < PAGE:
        return False
    n = size // PAGE
    with open(db_path, "rb") as f:
        page1 = f.read(PAGE)
        if len(page1) < PAGE or not verify_key(enc_key, page1):
            if verbose:
                print(f"    [!] HMAC 校验失败: {os.path.basename(db_path)}")
            return False
        with open(out_path, "wb") as out:
            out.write(decrypt_page(enc_key, page1, 1))
            for pgno in range(2, n + 1):
                page = f.read(PAGE)
                if len(page) < PAGE:
                    break
                out.write(decrypt_page(enc_key, page, pgno))

    frames = skipped = 0
    fsize = n * PAGE
    wal_path = db_path + "-wal"
    if os.path.exists(wal_path):
        wal = open(wal_path, "rb").read()          # WAL 本身有上限（通常 4MB），整个读没问题
        with open(out_path, "r+b") as out:
            for pgno, fpage in wal_frames(wal):
                pos = (pgno - 1) * PAGE
                if pos + PAGE <= fsize:
                    out.seek(pos)
                    out.write(decrypt_page(enc_key, fpage, pgno))
                elif pos == fsize:
                    out.seek(pos)
                    out.write(decrypt_page(enc_key, fpage, pgno))
                    fsize += PAGE
                else:
                    skipped += 1               # 页面不连续：不猜，只记录
                frames += 1
    if skipped:
        print(f"    [!] {os.path.basename(db_path)}: {skipped} 个 WAL 帧因页面不连续被跳过")
    if verbose:
        print(f"    [+] {os.path.basename(db_path)} -> {n}页 (wal {frames}帧)")
    return True


def collect_candidates(log_path):
    """scan.log -> {salt: [key_hex, ...]}。同一台机器上多个微信账号会有多套密钥，
    同一 salt 也可能出现多个候选，全部留着逐个验签。"""
    pat = re.compile(r"KEY=([0-9a-f]{64}) SALT=([0-9a-f]{32}|-)")
    cands = {}
    if not os.path.exists(log_path):
        return cands
    for line in open(log_path, encoding="utf-8", errors="ignore"):
        if "[CAND]" not in line:
            continue
        m = pat.search(line)
        if not m:
            continue
        key, salt = m.group(1), m.group(2)
        if salt == "-":
            continue
        if key not in cands.setdefault(salt, []):
            cands[salt].append(key)
    return cands


DB_GROUP_HINTS = {"message", "contact", "session", "general", "hardlink", "media", "sns", "favorite"}


def is_db_storage(p):
    """判断一个目录本身是不是 WCDB 的库目录（db_storage）。"""
    if not os.path.isdir(p):
        return False
    if glob.glob(os.path.join(p, "*.db")):
        return True
    subs = {os.path.basename(d) for d in glob.glob(os.path.join(p, "*")) if os.path.isdir(d)}
    return bool(subs & DB_GROUP_HINTS)


def candidate_db_dirs(path):
    """给定 db_storage / 账号目录 / xwechat_files，返回候选的 db_storage 列表。"""
    if is_db_storage(path):
        return [path]
    outs = [d for d in sorted(glob.glob(os.path.join(path, "*", "db_storage"))) if is_db_storage(d)]
    if outs:
        return outs
    return [d for d in sorted(glob.glob(os.path.join(path, "*"))) if is_db_storage(d)]


def verify_dir(db_dir, cands):
    """返回该目录里能用任一候选密钥解开的库数。"""
    dbs = sorted(glob.glob(os.path.join(db_dir, "**", "*.db"), recursive=True))
    ok = 0
    for db in dbs:
        try:
            head = open(db, "rb").read(PAGE)
        except OSError:
            continue
        if len(head) < PAGE:
            continue
        for k in cands.get(head[:16].hex(), []):
            if verify_key(bytes.fromhex(k), head):
                ok += 1
                break
    return ok, len(dbs)


def is_logged_in_account(account_dir):
    """xwechat_files/all_users/login/<wxid>/ 有目录 = 该账号最近登录过（当前登录的那个通常在里面）。"""
    acct = os.path.basename(os.path.abspath(account_dir))
    root = os.path.dirname(os.path.dirname(os.path.abspath(account_dir)))  # xwechat_files
    for d in glob.glob(os.path.join(root, "all_users", "login", "*")):
        if acct.startswith(os.path.basename(d)):
            return True
    # 兜底：数据目录里最新写入的库时间
    return False


def newest_mtime(db_dir):
    files = glob.glob(os.path.join(db_dir, "**", "*.db"), recursive=True)
    return max((os.path.getmtime(f) for f in files), default=0)


def pick_db_dir(dirs, cands):
    """多账号残留时，挑出"当前登录"的那个：先看能否用活进程里的密钥验签，
    再参考 all_users/login 标记与最近写入时间。"""
    scored = []
    for d in dirs:
        ok, total = verify_dir(d, cands)
        hint = is_logged_in_account(d)
        mt = newest_mtime(d)
        scored.append((ok, hint, mt, d))
        print(f"   候选 {os.path.basename(os.path.dirname(d))}: 验签 {ok}/{total} 库"
              f"{' · 登录标记' if hint else ''} · 最近写入 {__import__('datetime').datetime.fromtimestamp(mt):%m-%d %H:%M}")
    scored.sort(key=lambda x: (x[0], x[1], x[2]), reverse=True)
    ok, hint, _mt, best = scored[0]
    if ok == 0:
        return None
    if len(scored) > 1:
        print(f"   → 当前登录账号: {best}（其他为历史残留）")
    return best


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("用法: python3 wxdecrypt.py <db_storage或账号目录或xwechat_files> <wxkey scan.log> [输出目录]")
        raise SystemExit(2)
    db_dir = sys.argv[1]
    log = sys.argv[2]
    out_dir = sys.argv[3] if len(sys.argv) > 3 else None

    cands = collect_candidates(log)
    n_keys = sum(len(v) for v in cands.values())
    print(f"候选密钥 {n_keys} 条 / {len(cands)} 个 salt")

    dirs = candidate_db_dirs(db_dir)
    if not dirs:
        print(f"!! {db_dir} 下没找到 *.db")
        raise SystemExit(1)
    if len(dirs) > 1:
        print(f"发现 {len(dirs)} 个可能的账号目录，按验签结果自动选：")
        chosen = pick_db_dir(dirs, cands)
        if not chosen:
            print("!! 没有任何目录能验签通过；用 -DbDir 明确指定账号目录")
            raise SystemExit(1)
        print(f"   选定: {chosen}")
        db_dir = chosen
    if len(dirs) == 1:
        print(f"账号目录: {db_dir}")
    with open("chosen_dbdir.txt", "w", encoding="utf-8") as f:
        f.write(os.path.abspath(db_dir))

    dbs = sorted(glob.glob(os.path.join(db_dir, "**", "*.db"), recursive=True))
    ok = fail = 0
    for db in dbs:
        head = open(db, "rb").read(PAGE)
        keys = cands.get(head[:16].hex(), [])
        rel = os.path.relpath(db, db_dir)
        if not keys:
            print(f"  [ ] {rel:38s} salt={head[:16].hex()} 无候选")
            fail += 1
            continue
        good = None
        for k in keys:                      # 同 salt 多个候选时逐个试
            if verify_key(bytes.fromhex(k), head):
                good = k
                break
        if not good:
            print(f"  [x] {rel:38s} {len(keys)} 个候选全部 HMAC 校验失败")
            fail += 1
            continue
        if out_dir:
            out = os.path.join(out_dir, rel)
            os.makedirs(os.path.dirname(out), exist_ok=True)
            if decrypt_db(db, out, bytes.fromhex(good), verbose=True):
                ok += 1
            else:
                fail += 1
        else:
            print(f"  [v] {rel:38s} hmac=ok")
            ok += 1
    print(f"成功 {ok} / 失败 {fail}")
    if ok == 0 or fail:
        raise SystemExit(1)   # 调用方（run.ps1/run.sh）要能看见失败
