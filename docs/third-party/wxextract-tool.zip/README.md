# 微信 4.1+ (Windows) 聊天记录提取 — Windows 原生版

只读扫描微信进程内存取密钥 → 解密本机微信数据库 → 导出聊天记录 → 打包 zip。

**不会**：注入进程、hook、修改微信文件、联网上传、后台驻留、删除痕迹。全程在一个可见的控制台里跑完，
约 40 秒 ~ 1.5 分钟，结束时打印产出路径。

---

## 前置条件

- Windows 10/11 **x64**（32 位系统不支持）
- 微信 **4.x** 已登录并在运行（密钥只在登录期间驻留进程内存，退出登录就取不到了）
- 建议**以管理员身份**运行（同账号下普通权限通常也能跑；跨用户/RDP 会话必须管理员）
- 磁盘留约 2GB（解密副本 ~380MB + 导出 + zip）

## 用法

在目标机上，把整个目录放到任意位置，然后：

```powershell
# 在可见的控制台里执行（推荐）
powershell -NoProfile -ExecutionPolicy Bypass -File .\run.ps1

# 或者直接双击 run.bat（会弹出一个可见的控制台窗口）
```

常用参数：

```powershell
.\run.ps1 -DbDir "C:\Users\xx\Documents\xwechat_files\wxid_xxx_56eb\db_storage"   # 手动指定数据目录
.\run.ps1 -WithKeys      # 额外把数据库密钥写进 zip（默认不写）
.\run.ps1 -InstallDeps   # 解压 zstd 报错时先装 zstandard
.\run.ps1 -Python "C:\Python312\python.exe"   # 指定 Python
```

产出：`wechat-chatlog-<时间戳>.zip`，解压后：

| 路径 | 内容 |
|---|---|
| `聊天记录.html` | **单文件查看器，双击用浏览器打开**：左侧会话列表、关键词搜索、点击跳转 |
| `export/index.json` | 会话清单（备注名、条数、时间范围） |
| `export/jsonl/<会话>.jsonl` | 逐条结构化消息（发送者 / 类型 / 时间戳 / 渲染文本） |
| `export/txt/<会话>.txt` | 同内容的可读文本 |

查看器完全离线（数据和 JS 都在同一个文件里，不联网、无外部资源），窗内搜索同时匹配会话名与消息内容。

**默认排除群聊**（只要单聊）。要带上群聊加 `-IncludeGroups`。

## 需要拷到目标机的文件

| 文件 | 作用 |
|---|---|
| `wxkey.exe` | 只读内存取密钥（x64 .NET，系统自带运行时，无需安装） |
| `wxdecrypt.py` | 解密 SQLCipher4 库 + 按规范重放 WAL |
| `wxexport.py` | 解析消息、ZSTD 解压、导出 |
| `libzstd.dll` | zstd 解压（官方 facebook/zstd v1.5.6 的 x64 DLL，免 pip） |
| `mkzip.py` | 打包 zip（路径用 `/` 分隔、支持 ZIP64；PS 的 Compress-Archive 会写 `\`，跨平台解压会乱） |
| `python/` | 便携 CPython 3.12 x64，免装 Python；若目标机已有 Python 3.8+ 可删 |
| `run.ps1` / `run.bat` | 一键流程入口 |

`wxkey.exe` 若被删，可用系统自带的编译器重建（在目标机执行）：

```
csc /nologo /optimize+ /platform:x64 /out:wxkey.exe wxkey.cs
```

## 实现要点

- **密钥**：微信 4.1 把每个库的 `x'<32字节key><16字节salt>'` 放在进程内 `com.Tencent.WCDB.Config.Cipher`
  对象里（XOR 掩码）。`wxkey.exe` 走「找字符串 → 找 string 对象引用 → 取 config 指针 → 读 blob → 解码」这条路，
  不依赖版本偏移。取到的每个候选都用数据库第 1 页的 HMAC-SHA512 **验签**，验过才用。
- **解密**：SQLCipher 4，`AES-256-CBC` + `HMAC-SHA512`，page 4096，reserve 80（IV 16 + HMAC 64）。
  Windows 上走系统 CNG（`bcrypt.dll`），零第三方依赖；输出与 OpenSSL 实现逐字节一致（已对 sha256 验证）。
  **逐页流式**加解密，不把整个库读进内存（目标机记录库可能好几个 GB）。
- **WAL**：只重放 salt 与 WAL 头一致、且帧校验和通过的帧。Windows 微信通常在 WAL 里留大量**陈旧帧**
  （salt 不匹配），硬套会毁库 —— 这是本项目实现里最关键的坑。
- **消息**：`message_content` 是 ZSTD；`Msg_<md5(talker)>` 表名反查联系人；`real_sender_id` → Name2Id → 群昵称；
  `local_type` 高 32 位是子类型（先与 `0xFFFFFFFF` 掩码取基础类型）。

## 默认行为

- 只导**单聊 + 服务号/公众号**，群聊整表跳过（`-IncludeGroups` 可恢复）
- 导出内容：文本 / 表情 / 图片 / 语音 / 视频 / 文件 / 引用 / 系统消息等**全部消息类型**
  （非文本类型渲染成 `[图片]`、`[语音]`、`[引用] …` 这样的占位标记，媒体文件本体不解）
- 会话名优先取备注名 → 昵称 → 别名 → wxid

## 已知限制

- 只覆盖 PC 微信本地保留的记录（重装/清理会丢更早的；本机实测起点是装机那天）
- 手机端「聊天记录备份到电脑」的 `Backup/` 用的是手机端独立密钥，PC 侧解不开
- 只导出**文本类**内容；图片/语音/视频本体是 `msg/attach` 下加密的 `.dat`，包里仅占位标记
- 只在微信 4.1.15.11 实测；4.0.x 或更高版本结构可能变化（先跑 `wxkey.exe scan` 看有无候选）

## 安全与合规

- `scan.log` 与 `--with-keys` 生成的 `keys.txt` **能解开本机全部微信数据库**，别把工作目录整体外发
- 只能用于**你自己的账号、你自己的设备**，或已获得机器主人明确知情同意的设备
- 导出的聊天记录包含对方（及群内第三方）的消息，传播范围请自行控制
- 微信官方对这类工具态度强硬（同类开源项目已收到法务函并下架），请自行评估风险
