@echo off
rem WeChat chatlog extractor - Windows native, console visible
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run.ps1" %*
pause
