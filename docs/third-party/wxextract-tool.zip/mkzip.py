#!/usr/bin/env python3
"""把目录打成 zip：路径统一用 / 分隔（Compress-Archive 在 PS 5.1 下会写 \，跨平台解压会错），
并且走 ZIP64，不受 2GB 上限影响。用法: python3 mkzip.py <源目录> <目标.zip>"""
import os
import sys
import zipfile


def main() -> int:
    if len(sys.argv) < 3:
        print("用法: python3 mkzip.py <源目录> <目标.zip>")
        return 2
    src, dst = sys.argv[1], sys.argv[2]
    if not os.path.isdir(src):
        print(f"源目录不存在: {src}")
        return 1
    if os.path.exists(dst):
        os.remove(dst)
    n = 0
    with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True) as z:
        for root, _dirs, files in os.walk(src):
            for f in files:
                p = os.path.join(root, f)
                z.write(p, os.path.relpath(p, src).replace(os.sep, "/"))
                n += 1
    print(f"   打包完成: {dst}  ({os.path.getsize(dst) / 1048576:.1f}MB, {n} 个文件)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
